function saveMap(fnameOut,roiHSV,peakParameter,peakResponse,peakParameterStd,roiHSVRescaled,peakResponseLabels,peakParameterStdLabels,cutUp,cutDown,offset,mapParams,traces,onsets,responsesStd)
                                                                                                                                                                                      
save(fnameOut,'roiHSV','peakParameter','peakResponse','peakParameterStd','roiHSVRescaled','peakResponseLabels','peakParameterStdLabels','cutUp','cutDown','offset','mapParams','traces','onsets','responsesStd');
 