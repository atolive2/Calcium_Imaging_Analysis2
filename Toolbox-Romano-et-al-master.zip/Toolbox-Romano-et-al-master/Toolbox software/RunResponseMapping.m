clear all; 
set(0,'DefaultFigureWindowStyle','docked','DefaultFigureColor','w')
[roiHSV,peakParameter,peakResponse,peakParameterStd,im,totalCells,mapData,roiHSVRescaled,peakResponseLabels,peakParameterStdLabels,cellper,pixROIs,mx,cutUp,cutDown,offset,traces,onsets,offsets,responses,responsesStd,prevFrame,eventDuration,params,plotRows,transpa,mapParams,fnameOut,hIm]=MapResponses();


    